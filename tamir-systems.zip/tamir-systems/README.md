# Tamir Systems — Premium Security Website

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
# Edit .env.local and add your Supabase credentials:
# NEXT_PUBLIC_SUPABASE_URL=your_url
# NEXT_PUBLIC_SUPABASE_ANON_KEY=your_key

# 3. Run development server
npm run dev

# 4. Build for production
npm run build
npm start
```

## Project Structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout + metadata
│   ├── page.tsx            # Main page
│   └── globals.css         # Global styles
├── components/
│   ├── layout/
│   │   ├── Navbar.tsx      # Animated sticky navbar
│   │   ├── Footer.tsx      # Footer
│   │   └── WhatsAppFloat.tsx # Floating WhatsApp button
│   ├── sections/
│   │   ├── HeroSection.tsx
│   │   ├── ServicesSection.tsx
│   │   ├── ProjectsSection.tsx
│   │   ├── TestimonialsSection.tsx
│   │   └── ContactSection.tsx
│   └── ui/
│       ├── Button.tsx
│       └── SectionLabel.tsx
├── animations/
│   └── variants.ts         # Framer Motion variants
├── hooks/
│   ├── useScrolled.ts
│   └── useInView.ts
├── lib/
│   ├── data.ts             # All static content
│   ├── supabase.ts         # Supabase client
│   └── utils.ts
└── types/
    └── index.ts
```

## Supabase Setup (when ready)

Create a `leads` table in Supabase:

```sql
create table leads (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  phone text not null,
  email text,
  message text not null,
  created_at timestamp with time zone default now()
);
```

Then update `ContactSection.tsx` to use the supabase client.

## Deployment

Deploy to Vercel (recommended):
1. Push to GitHub
2. Import project at vercel.com
3. Add environment variables
4. Deploy!
