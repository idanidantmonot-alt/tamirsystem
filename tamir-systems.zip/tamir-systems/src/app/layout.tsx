import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tamir Systems | מצלמות אבטחה מתקדמות",
  description: "פתרונות אבטחה מתקדמים לבית ולעסק. התקנת מצלמות IP, מערכות ניטור, ושירות 24/7 ברחבי הארץ.",
  keywords: "מצלמות אבטחה, התקנת מצלמות, מערכות אבטחה, CCTV, תמיר מערכות",
  authors: [{ name: "Tamir Systems" }],
  openGraph: {
    title: "Tamir Systems | מצלמות אבטחה מתקדמות",
    description: "פתרונות אבטחה מתקדמים לבית ולעסק",
    type: "website",
    locale: "he_IL",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="he" dir="rtl">
      <body className="noise">
        <div className="scan-line" />
        {children}
      </body>
    </html>
  );
}
