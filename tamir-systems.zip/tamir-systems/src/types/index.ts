export interface Lead {
  id?: string;
  name: string;
  phone: string;
  email?: string;
  message: string;
  created_at?: string;
}

export interface Service {
  id: string;
  icon: string;
  title: string;
  description: string;
  features: string[];
}

export interface Project {
  id: string;
  title: string;
  category: string;
  location: string;
  image: string;
  description: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
  rating: number;
  avatar: string;
}

export interface NavItem {
  label: string;
  href: string;
}
