"use client";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface ButtonProps {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "whatsapp";
  size?: "sm" | "md" | "lg";
  href?: string;
  onClick?: () => void;
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
  target?: string;
}

export default function Button({
  children,
  variant = "primary",
  size = "md",
  href,
  onClick,
  className,
  type = "button",
  disabled,
  target,
}: ButtonProps) {
  const base =
    "relative inline-flex items-center justify-center gap-2 font-semibold rounded-full transition-all duration-300 overflow-hidden group";

  const variants = {
    primary:
      "bg-neon-blue text-navy-950 hover:shadow-neon-lg hover:scale-105",
    secondary:
      "glass neon-border text-neon-blue hover:bg-neon-blue/10 hover:shadow-neon",
    ghost:
      "text-slate-300 hover:text-white hover:bg-white/5",
    whatsapp:
      "bg-[#25d366] text-white hover:bg-[#1da851] hover:shadow-[0_0_30px_rgba(37,211,102,0.4)] hover:scale-105",
  };

  const sizes = {
    sm: "text-sm px-5 py-2.5",
    md: "text-base px-7 py-3.5",
    lg: "text-lg px-9 py-4",
  };

  const classes = cn(base, variants[variant], sizes[size], disabled && "opacity-50 cursor-not-allowed", className);

  const content = (
    <>
      <span className="relative z-10">{children}</span>
      {variant === "primary" && (
        <span className="absolute inset-0 bg-white/20 translate-x-full group-hover:translate-x-[-200%] transition-transform duration-700 skew-x-12" />
      )}
    </>
  );

  if (href) {
    return (
      <motion.a
        href={href}
        target={target}
        rel={target === "_blank" ? "noopener noreferrer" : undefined}
        className={classes}
        whileTap={{ scale: 0.97 }}
      >
        {content}
      </motion.a>
    );
  }

  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={classes}
      whileTap={{ scale: 0.97 }}
    >
      {content}
    </motion.button>
  );
}
