import { cn } from "@/lib/utils";

interface SectionLabelProps {
  children: string;
  className?: string;
}

export default function SectionLabel({ children, className }: SectionLabelProps) {
  return (
    <div className={cn("inline-flex items-center gap-2 mb-4", className)}>
      <span className="w-8 h-px bg-neon-blue" />
      <span className="text-neon-blue font-mono text-sm tracking-widest uppercase">
        {children}
      </span>
      <span className="w-8 h-px bg-neon-blue" />
    </div>
  );
}
