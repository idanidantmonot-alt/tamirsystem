import { Shield, Instagram, Phone, Mail } from "lucide-react";
import { NAV_ITEMS } from "@/lib/data";

export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 bg-navy-950">
      <div className="container-wide py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-xl bg-neon-blue/10 border border-neon-blue/30 flex items-center justify-center">
                <Shield className="w-5 h-5 text-neon-blue" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-display font-bold text-white text-lg">TAMIR</span>
                <span className="font-mono text-neon-blue text-[10px] tracking-widest">Systems</span>
              </div>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed">
              פתרונות אבטחה מתקדמים לבית ולעסק. מעל 500 פרויקטים ברחבי הארץ.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm tracking-wider uppercase">ניווט</h4>
            <ul className="space-y-2">
              {NAV_ITEMS.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="text-slate-500 hover:text-neon-blue text-sm transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm tracking-wider uppercase">צור קשר</h4>
            <ul className="space-y-3">
              <li>
                <a href="tel:0556899009" className="flex items-center gap-2 text-slate-500 hover:text-neon-blue text-sm transition-colors">
                  <Phone className="w-4 h-4" />
                  055-689-9009
                </a>
              </li>
              <li>
                <a href="mailto:tamir.t.sys@gmail.com" className="flex items-center gap-2 text-slate-500 hover:text-neon-blue text-sm transition-colors">
                  <Mail className="w-4 h-4" />
                  tamir.t.sys@gmail.com
                </a>
              </li>
              <li>
                <a
                  href="https://www.instagram.com/tamit_systems"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-slate-500 hover:text-pink-400 text-sm transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                  @tamit_systems
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="gradient-line mt-12 mb-6" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-slate-600 text-sm">
            &copy; 2026 Tamir Systems. כל הזכויות שמורות.
          </p>
          <p className="text-slate-700 text-xs font-mono">
            Built with precision. Secured with trust.
          </p>
        </div>
      </div>
    </footer>
  );
}
