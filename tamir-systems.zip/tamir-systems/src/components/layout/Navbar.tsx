"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useScrolled } from "@/hooks/useScrolled";
import { NAV_ITEMS } from "@/lib/data";
import { cn } from "@/lib/utils";
import { Menu, X, Shield } from "lucide-react";

export default function Navbar() {
  const scrolled = useScrolled(60);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    el?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
          scrolled
            ? "glass border-b border-white/5 py-3"
            : "bg-transparent py-5"
        )}
      >
        <div className="container-wide flex items-center justify-between">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-2.5 cursor-pointer"
            onClick={() => handleNav("#hero")}
            whileHover={{ scale: 1.02 }}
          >
            <div className="w-9 h-9 rounded-xl bg-neon-blue/10 border border-neon-blue/30 flex items-center justify-center">
              <Shield className="w-5 h-5 text-neon-blue" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-display font-bold text-white text-lg tracking-tight">
                TAMIR
              </span>
              <span className="font-mono text-neon-blue text-[10px] tracking-[0.2em] uppercase">
                Systems
              </span>
            </div>
          </motion.div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <motion.button
                key={item.href}
                onClick={() => handleNav(item.href)}
                className="relative px-4 py-2 text-slate-400 hover:text-white text-sm font-medium transition-colors duration-200 group"
                whileHover={{ y: -1 }}
              >
                {item.label}
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-px bg-neon-blue group-hover:w-4/5 transition-all duration-300" />
              </motion.button>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <motion.a
              href="tel:0556899009"
              className="text-slate-400 hover:text-neon-blue text-sm font-mono transition-colors"
              whileHover={{ scale: 1.02 }}
            >
              055-689-9009
            </motion.a>
            <motion.a
              href="https://wa.me/972556899009?text=שלום%20תמיר%20מערכות,%20אני%20מעוניין%20בשירותי%20מצלמות%20אבטחה"
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-2.5 bg-neon-blue text-navy-950 rounded-full text-sm font-bold hover:shadow-neon transition-all duration-300 hover:scale-105"
              whileTap={{ scale: 0.97 }}
            >
              וואטסאפ
            </motion.a>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 text-slate-400 hover:text-white"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </motion.header>

      {/* Mobile Fullscreen Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, clipPath: "circle(0% at calc(100% - 40px) 40px)" }}
            animate={{ opacity: 1, clipPath: "circle(150% at calc(100% - 40px) 40px)" }}
            exit={{ opacity: 0, clipPath: "circle(0% at calc(100% - 40px) 40px)" }}
            transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="fixed inset-0 z-40 bg-navy-950/98 backdrop-blur-xl flex flex-col items-center justify-center"
          >
            <nav className="flex flex-col items-center gap-6">
              {NAV_ITEMS.map((item, i) => (
                <motion.button
                  key={item.href}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + i * 0.08 }}
                  onClick={() => handleNav(item.href)}
                  className="text-3xl font-display font-bold text-white hover:text-neon-blue transition-colors"
                >
                  {item.label}
                </motion.button>
              ))}
              <motion.a
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                href="https://wa.me/972556899009?text=שלום%20תמיר%20מערכות,%20אני%20מעוניין%20בשירותי%20מצלמות%20אבטחה"
                target="_blank"
                className="mt-6 px-10 py-4 bg-neon-blue text-navy-950 rounded-full text-xl font-bold"
                onClick={() => setMobileOpen(false)}
              >
                💬 וואטסאפ
              </motion.a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
