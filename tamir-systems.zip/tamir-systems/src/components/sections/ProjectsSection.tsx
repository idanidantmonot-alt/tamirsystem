"use client";
import { motion } from "framer-motion";
import Image from "next/image";
import { useState } from "react";
import { X, MapPin } from "lucide-react";
import { useInView } from "@/hooks/useInView";
import { staggerContainer, staggerItem } from "@/animations/variants";
import { PROJECTS } from "@/lib/data";
import SectionLabel from "@/components/ui/SectionLabel";
import { Project } from "@/types";

export default function ProjectsSection() {
  const { ref, inView } = useInView();
  const [selected, setSelected] = useState<Project | null>(null);

  return (
    <section id="projects" className="section-padding relative">
      <div className="container-wide" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <SectionLabel>פרויקטים</SectionLabel>
          <h2 className="font-display text-4xl md:text-5xl font-extrabold text-white mt-2 mb-4">
            העבודות{" "}
            <span className="text-neon-blue">שלנו</span>
          </h2>
          <p className="text-slate-400 max-w-lg mx-auto">
            מגוון פרויקטים שהשלמנו ברחבי הארץ — מבתים פרטיים ועד מפעלים גדולים
          </p>
        </motion.div>

        {/* Masonry-style Grid */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          {PROJECTS.map((project, i) => (
            <motion.div
              key={project.id}
              variants={staggerItem}
              className={`group relative rounded-2xl overflow-hidden cursor-pointer ${
                i === 0 ? "md:col-span-2 lg:col-span-1" : ""
              }`}
              style={{ aspectRatio: i === 0 ? "16/10" : "4/3" }}
              onClick={() => setSelected(project)}
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.3 }}
            >
              <Image
                src={project.image}
                alt={project.title}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-110"
              />

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 via-navy-950/30 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />

              {/* Top badge */}
              <div className="absolute top-4 right-4 glass rounded-full px-3 py-1 text-xs text-neon-blue font-mono border border-neon-blue/20 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-1 group-hover:translate-y-0">
                {project.category}
              </div>

              {/* Bottom content */}
              <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs mb-1.5">
                  <MapPin className="w-3 h-3" />
                  {project.location}
                </div>
                <h3 className="font-display text-lg font-bold text-white">
                  {project.title}
                </h3>
                <p className="text-slate-400 text-sm mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  {project.description}
                </p>
              </div>

              {/* Neon border on hover */}
              <div className="absolute inset-0 rounded-2xl border border-neon-blue/0 group-hover:border-neon-blue/20 transition-all duration-300" />
            </motion.div>
          ))}
        </motion.div>

        {/* Instagram CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="text-center mt-12"
        >
          <a
            href="https://www.instagram.com/tamit_systems"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full glass border border-pink-500/20 text-pink-400 hover:border-pink-500/50 hover:bg-pink-500/5 transition-all duration-300 font-medium"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
            </svg>
            ראה עוד עבודות באינסטגרם @tamit_systems
          </a>
        </motion.div>
      </div>

      {/* Lightbox */}
      {selected && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelected(null)}
        >
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative max-w-2xl w-full rounded-2xl overflow-hidden glass-strong"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-64 md:h-96">
              <Image src={selected.image} alt={selected.title} fill className="object-cover" />
            </div>
            <div className="p-6">
              <div className="flex items-center gap-2 text-neon-blue text-sm font-mono mb-2">
                <MapPin className="w-4 h-4" />
                {selected.location} · {selected.category}
              </div>
              <h3 className="font-display text-2xl font-bold text-white mb-2">{selected.title}</h3>
              <p className="text-slate-400">{selected.description}</p>
            </div>
            <button
              onClick={() => setSelected(null)}
              className="absolute top-4 left-4 w-9 h-9 rounded-full glass flex items-center justify-center text-white hover:text-neon-blue transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </motion.div>
        </motion.div>
      )}
    </section>
  );
}
