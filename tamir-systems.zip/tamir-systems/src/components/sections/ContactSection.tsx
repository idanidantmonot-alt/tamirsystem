"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, Mail, Instagram, Send, CheckCircle, AlertCircle, Loader } from "lucide-react";
import { useInView } from "@/hooks/useInView";
import { staggerContainer, staggerItem } from "@/animations/variants";
import SectionLabel from "@/components/ui/SectionLabel";
import Button from "@/components/ui/Button";

type FormState = "idle" | "loading" | "success" | "error";

interface FormData {
  name: string;
  phone: string;
  email: string;
  message: string;
}

export default function ContactSection() {
  const { ref, inView } = useInView();
  const [formState, setFormState] = useState<FormState>("idle");
  const [form, setForm] = useState<FormData>({ name: "", phone: "", email: "", message: "" });
  const [errors, setErrors] = useState<Partial<FormData>>({});

  const validate = () => {
    const e: Partial<FormData> = {};
    if (!form.name.trim()) e.name = "שדה חובה";
    if (!form.phone.trim() || !/^0\d{8,9}$/.test(form.phone.replace(/[-\s]/g, "")))
      e.phone = "מספר טלפון לא תקין";
    if (!form.message.trim()) e.message = "שדה חובה";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setFormState("loading");
    try {
      // Supabase integration - will be added later
      await new Promise((resolve) => setTimeout(resolve, 1200));
      setFormState("success");
      setForm({ name: "", phone: "", email: "", message: "" });
      setTimeout(() => setFormState("idle"), 5000);
    } catch {
      setFormState("error");
      setTimeout(() => setFormState("idle"), 4000);
    }
  };

  const contactMethods = [
    {
      icon: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>,
      label: "וואטסאפ",
      value: "055-689-9009",
      href: "https://wa.me/972556899009?text=שלום%20תמיר%20מערכות,%20אני%20מעוניין%20בשירותי%20מצלמות%20אבטחה",
      color: "text-[#25d366]",
      borderColor: "border-[#25d366]/20 hover:border-[#25d366]/50",
    },
    {
      icon: <Phone className="w-5 h-5" />,
      label: "טלפון",
      value: "055-689-9009",
      href: "tel:0556899009",
      color: "text-neon-blue",
      borderColor: "border-neon-blue/20 hover:border-neon-blue/50",
    },
    {
      icon: <Mail className="w-5 h-5" />,
      label: "מייל",
      value: "tamir.t.sys@gmail.com",
      href: "mailto:tamir.t.sys@gmail.com",
      color: "text-red-400",
      borderColor: "border-red-400/20 hover:border-red-400/50",
    },
    {
      icon: <Instagram className="w-5 h-5" />,
      label: "אינסטגרם",
      value: "@tamit_systems",
      href: "https://www.instagram.com/tamit_systems",
      color: "text-pink-400",
      borderColor: "border-pink-400/20 hover:border-pink-400/50",
    },
  ];

  return (
    <section id="contact" className="section-padding relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-navy-800/30 to-transparent pointer-events-none" />

      <div className="container-wide" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <SectionLabel>צור קשר</SectionLabel>
          <h2 className="font-display text-4xl md:text-5xl font-extrabold text-white mt-2 mb-4">
            בואו{" "}
            <span className="text-neon-blue">נדבר</span>
          </h2>
          <p className="text-slate-400 max-w-lg mx-auto">
            מעוניינים בשירות? השאירו פרטים ונחזור אליכם תוך שעה
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Contact methods */}
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            className="flex flex-col gap-4"
          >
            <motion.h3
              variants={staggerItem}
              className="font-display text-xl font-bold text-white mb-2"
            >
              דרכי יצירת קשר
            </motion.h3>
            {contactMethods.map((m, i) => (
              <motion.a
                key={i}
                variants={staggerItem}
                href={m.href}
                target={m.href.startsWith("http") ? "_blank" : undefined}
                rel={m.href.startsWith("http") ? "noopener noreferrer" : undefined}
                className={`flex items-center gap-4 glass rounded-2xl px-6 py-4 border transition-all duration-300 hover:translate-x-[-4px] group ${m.borderColor}`}
              >
                <span className={`${m.color} flex-shrink-0`}>{m.icon}</span>
                <div>
                  <div className="text-slate-400 text-xs font-mono mb-0.5">{m.label}</div>
                  <div className="text-white font-semibold text-sm group-hover:text-neon-blue transition-colors">{m.value}</div>
                </div>
              </motion.a>
            ))}

            <motion.div
              variants={staggerItem}
              className="glass rounded-2xl p-6 border border-white/5 mt-2"
            >
              <div className="flex items-center gap-2 text-neon-blue mb-3">
                <span className="w-2 h-2 rounded-full bg-neon-blue animate-pulse" />
                <span className="text-sm font-mono">זמין עכשיו</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">
                שירות לקוחות זמין <strong className="text-white">24/7</strong>.<br />
                זמן מענה ממוצע: <strong className="text-neon-blue">פחות משעה</strong>
              </p>
            </motion.div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="glass-strong rounded-2xl p-8 border border-white/8"
          >
            {formState === "success" ? (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center justify-center h-full py-10 text-center gap-4"
              >
                <CheckCircle className="w-16 h-16 text-neon-blue" />
                <h3 className="font-display text-2xl font-bold text-white">ההודעה נשלחה!</h3>
                <p className="text-slate-400">נחזור אליך תוך שעה. תודה!</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <h3 className="font-display text-xl font-bold text-white mb-6">
                  השאר פרטים
                </h3>

                {[
                  { id: "name", label: "שם מלא *", type: "text", placeholder: "ישראל ישראלי" },
                  { id: "phone", label: "טלפון *", type: "tel", placeholder: "05X-XXXXXXX" },
                  { id: "email", label: "דוא\"ל", type: "email", placeholder: "example@gmail.com" },
                ].map((field) => (
                  <div key={field.id}>
                    <label className="block text-slate-400 text-sm mb-1.5">{field.label}</label>
                    <input
                      type={field.type}
                      placeholder={field.placeholder}
                      value={form[field.id as keyof FormData]}
                      onChange={(e) => setForm({ ...form, [field.id]: e.target.value })}
                      className={`w-full bg-white/5 border rounded-xl px-4 py-3 text-white placeholder-slate-600 text-sm focus:outline-none focus:border-neon-blue/50 focus:bg-white/8 transition-all ${
                        errors[field.id as keyof FormData] ? "border-red-500/50" : "border-white/10"
                      }`}
                    />
                    {errors[field.id as keyof FormData] && (
                      <p className="text-red-400 text-xs mt-1">{errors[field.id as keyof FormData]}</p>
                    )}
                  </div>
                ))}

                <div>
                  <label className="block text-slate-400 text-sm mb-1.5">הודעה *</label>
                  <textarea
                    rows={4}
                    placeholder="ספר לנו במה נוכל לעזור..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className={`w-full bg-white/5 border rounded-xl px-4 py-3 text-white placeholder-slate-600 text-sm focus:outline-none focus:border-neon-blue/50 focus:bg-white/8 transition-all resize-none ${
                      errors.message ? "border-red-500/50" : "border-white/10"
                    }`}
                  />
                  {errors.message && (
                    <p className="text-red-400 text-xs mt-1">{errors.message}</p>
                  )}
                </div>

                {formState === "error" && (
                  <div className="flex items-center gap-2 text-red-400 text-sm">
                    <AlertCircle className="w-4 h-4" />
                    שגיאה בשליחה. נסה שוב.
                  </div>
                )}

                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  disabled={formState === "loading"}
                  className="w-full justify-center"
                >
                  {formState === "loading" ? (
                    <>
                      <Loader className="w-4 h-4 animate-spin" />
                      שולח...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      שלח הודעה
                    </>
                  )}
                </Button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
