"use client";
import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { useInView } from "@/hooks/useInView";
import { staggerContainer, staggerItem } from "@/animations/variants";
import { TESTIMONIALS } from "@/lib/data";
import SectionLabel from "@/components/ui/SectionLabel";

export default function TestimonialsSection() {
  const { ref, inView } = useInView();

  return (
    <section id="testimonials" className="section-padding relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-neon-blue/[0.02] to-transparent pointer-events-none" />

      <div className="container-wide" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <SectionLabel>המלצות</SectionLabel>
          <h2 className="font-display text-4xl md:text-5xl font-extrabold text-white mt-2 mb-4">
            לקוחות{" "}
            <span className="text-neon-blue">מרוצים</span>
          </h2>
          <p className="text-slate-400 max-w-lg mx-auto">
            98% מהלקוחות שלנו ממליצים עלינו לחברים ולמשפחה
          </p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {TESTIMONIALS.map((t) => (
            <motion.div
              key={t.id}
              variants={staggerItem}
              whileHover={{ y: -6 }}
              className="group glass rounded-2xl p-7 border border-white/5 hover:border-neon-blue/20 transition-all duration-400 relative overflow-hidden"
            >
              {/* Top glow line */}
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-neon-blue/0 group-hover:via-neon-blue/30 to-transparent transition-all duration-500" />

              {/* Quote icon */}
              <Quote className="w-8 h-8 text-neon-blue/20 mb-4" />

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-neon-blue text-neon-blue" />
                ))}
              </div>

              {/* Content */}
              <p className="text-slate-300 text-sm leading-relaxed mb-6 italic">
                &ldquo;{t.content}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-white/5">
                <div className="w-10 h-10 rounded-full bg-neon-blue/10 border border-neon-blue/20 flex items-center justify-center text-neon-blue font-bold text-sm font-mono">
                  {t.avatar}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{t.name}</div>
                  <div className="text-slate-500 text-xs">
                    {t.role} · {t.company}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
