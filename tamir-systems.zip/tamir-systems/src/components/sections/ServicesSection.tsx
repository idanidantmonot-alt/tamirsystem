"use client";
import { motion } from "framer-motion";
import { Camera, Monitor, Building2, Wrench, Home, Shield } from "lucide-react";
import { staggerContainer, staggerItem } from "@/animations/variants";
import { useInView } from "@/hooks/useInView";
import { SERVICES } from "@/lib/data";
import SectionLabel from "@/components/ui/SectionLabel";

const iconMap: Record<string, React.ElementType> = {
  Camera, Monitor, Building2, Wrench, Home, Shield,
};

export default function ServicesSection() {
  const { ref, inView } = useInView();

  return (
    <section id="services" className="section-padding relative">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-navy-800/20 to-transparent pointer-events-none" />

      <div className="container-wide" ref={ref}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <SectionLabel>השירותים שלנו</SectionLabel>
          <h2 className="font-display text-4xl md:text-5xl font-extrabold text-white mt-2 mb-4">
            פתרונות אבטחה{" "}
            <span className="text-neon-blue">מקיפים</span>
          </h2>
          <p className="text-slate-400 max-w-lg mx-auto">
            ממצלמות בודדות ועד מערכות ניטור מורכבות — אנחנו מכסים את כל הצרכים שלך
          </p>
        </motion.div>

        {/* Cards Grid */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {SERVICES.map((service) => {
            const Icon = iconMap[service.icon] || Shield;
            return (
              <motion.div
                key={service.id}
                variants={staggerItem}
                whileHover={{ y: -8, scale: 1.01 }}
                className="group glass rounded-2xl p-7 border border-white/5 hover:border-neon-blue/25 transition-all duration-400 cursor-default relative overflow-hidden"
              >
                {/* Hover glow */}
                <div className="absolute inset-0 bg-neon-blue/0 group-hover:bg-neon-blue/[0.03] transition-colors duration-400 rounded-2xl" />
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-neon-blue/0 group-hover:via-neon-blue/40 to-transparent transition-all duration-400" />

                {/* Icon */}
                <div className="w-13 h-13 rounded-xl bg-neon-blue/10 border border-neon-blue/20 flex items-center justify-center mb-5 group-hover:bg-neon-blue/15 group-hover:border-neon-blue/40 transition-all duration-300 w-12 h-12">
                  <Icon className="w-6 h-6 text-neon-blue" />
                </div>

                <h3 className="font-display text-xl font-bold text-white mb-3 group-hover:text-neon-blue transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-slate-500 text-sm leading-relaxed mb-5">
                  {service.description}
                </p>

                <ul className="space-y-2">
                  {service.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-neon-blue flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
