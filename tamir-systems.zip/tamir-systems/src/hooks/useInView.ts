"use client";
import { useInView as useFramerInView } from "framer-motion";
import { useRef } from "react";

export function useInView(threshold = 0.15) {
  const ref = useRef(null);
  const inView = useFramerInView(ref, { once: true, amount: threshold });
  return { ref, inView };
}
