import { Service, Project, Testimonial, NavItem } from "@/types";

export const NAV_ITEMS: NavItem[] = [
  { label: "בית", href: "#hero" },
  { label: "שירותים", href: "#services" },
  { label: "פרויקטים", href: "#projects" },
  { label: "המלצות", href: "#testimonials" },
  { label: "צור קשר", href: "#contact" },
];

export const SERVICES: Service[] = [
  {
    id: "ip-cameras",
    icon: "Camera",
    title: "מצלמות IP מתקדמות",
    description: "מצלמות 4K עם ראיית לילה, זיהוי תנועה חכם, וגישה מרחוק בזמן אמת",
    features: ["רזולוציה 4K Ultra HD", "ראיית לילה 40 מטר", "זיהוי פנים AI", "התראות סמארטפון"],
  },
  {
    id: "remote-view",
    icon: "Monitor",
    title: "ניטור מרחוק 24/7",
    description: "צפה בכל מצלמה מכל מקום בעולם דרך אפליקציה חכמה ומהירה",
    features: ["אפליקציה iOS & Android", "שידור חי HD", "הקלטה לענן", "גישה מרובת משתמשים"],
  },
  {
    id: "business",
    icon: "Building2",
    title: "פתרונות לעסקים",
    description: "מערכות אבטחה מקיפות לעסקים, מחנויות קטנות ועד מפעלים גדולים",
    features: ["סקר אבטחה חינמי", "תכנון מותאם אישית", "התקנה מקצועית", "הדרכת צוות"],
  },
  {
    id: "maintenance",
    icon: "Wrench",
    title: "שירות ותחזוקה",
    description: "שירות טכני מהיר, חוזי תחזוקה שנתיים, ואחריות מלאה על כל עבודה",
    features: ["שירות חירום 24/7", "הגעה לכל הארץ", "אחריות 3 שנים", "חוזי תחזוקה"],
  },
  {
    id: "smart-home",
    icon: "Home",
    title: "בית חכם ואבטחה",
    description: "שילוב מצלמות עם מערכות בית חכם — שליטה מלאה ממקום אחד",
    features: ["אינטגרציה עם Google Home", "שליטה קולית", "אוטומציה חכמה", "חיסכון באנרגיה"],
  },
  {
    id: "alarm",
    icon: "Shield",
    title: "אזעקות ואינטרקום",
    description: "מערכות אזעקה מתקדמות ואינטרקום חכם לשכונות, בניינים ועסקים",
    features: ["אינטרקום וידאו", "אזעקה חכמה", "דלתות שליטה", "ניטור מרכזי"],
  },
];

export const PROJECTS: Project[] = [
  {
    id: "villa-tlv",
    title: "וילה פרטית",
    category: "מגורים",
    location: "תל אביב",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80",
    description: "מערכת 12 מצלמות 4K עם ניטור מרחוק",
  },
  {
    id: "mall-ra",
    title: "קניון מסחרי",
    category: "מסחרי",
    location: "רמת גן",
    image: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?w=800&q=80",
    description: "48 מצלמות עם מרכז ניטור מרכזי",
  },
  {
    id: "office-hrl",
    title: "קמפוס הייטק",
    category: "משרדים",
    location: "הרצליה",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80",
    description: "פתרון אבטחה מלא ל-3 בניינים",
  },
  {
    id: "warehouse-asd",
    title: "מחסן לוגיסטי",
    category: "תעשייה",
    location: "אשדוד",
    image: "https://images.unsplash.com/photo-1553413077-190dd305871c?w=800&q=80",
    description: "ניטור 360° של שטח 5,000 מ\"ר",
  },
  {
    id: "school-ntn",
    title: "מוסד חינוכי",
    category: "מוסדות",
    location: "נתניה",
    image: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=800&q=80",
    description: "24 מצלמות עם אינטגרציה לפיקוח",
  },
  {
    id: "hotel-eilat",
    title: "מלון בוטיק",
    category: "אירוח",
    location: "אילת",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&q=80",
    description: "מערכת אבטחה כוללת + אינטרקום",
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "1",
    name: "יוסי כהן",
    role: "בעל עסק",
    company: "רשת חנויות",
    content: "תמיר מערכות עשו עבודה מדהימה. המצלמות חדות, ההתקנה הייתה נקייה ומקצועית, והשירות אחרי המכירה מעולה. ממליץ בחום!",
    rating: 5,
    avatar: "YK",
  },
  {
    id: "2",
    name: "רחל לוי",
    role: "מנהלת נכסים",
    company: "חברת נדל\"ן",
    content: "עובדים עם תמיר מערכות כבר 3 שנים. אמינות, מקצועיות ומחירים הוגנים. כל פרויקט מסתיים בזמן ובאיכות גבוהה.",
    rating: 5,
    avatar: "RL",
  },
  {
    id: "3",
    name: "דני אברהם",
    role: "מנהל אבטחה",
    company: "קניון גדול",
    content: "הפרויקט הכי מורכב שעשינו — 48 מצלמות בקניון שלם. תמיר ניהל את הכל בצורה מושלמת. מרוצים מאוד.",
    rating: 5,
    avatar: "DA",
  },
];

export const STATS = [
  { value: "500+", label: "פרויקטים הושלמו" },
  { value: "10+", label: "שנות ניסיון" },
  { value: "24/7", label: "שירות ותמיכה" },
  { value: "98%", label: "לקוחות מרוצים" },
];
